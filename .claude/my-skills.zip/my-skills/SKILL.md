---
name: my-skills
description: The owner's personal library of every skill and tool they have installed, removed or refused, with full copies of the installed skills. Use whenever the user asks to list their skills or tools, asks what is installed, or asks to bring, load, use, install or run a skill or tool by name, in Arabic or English, e.g. "لستة المهارات", "قائمة الأدوات", "هات مهارة", "جيبلي المهارة", "ثبتلي", "شغل مهارة", "what skills do I have", "bring me ig-reel". Also use after installing, removing or refusing any skill or tool, to tell the user how to keep this library current.
license: Bundled skills keep their own MIT licenses (library/*-LICENSE)
---

# My skills library

The owner wants to ask for their skills and tools in any session, in any
repository, without doing anything themselves. This skill is that memory.
Reply in Arabic unless the user writes in another language.

Files in this folder:

- `registry.md`: every skill pack and tool, its source URL, what it contains,
  when it was installed, plus what was removed and what was refused and why.
- `library/<pack>.tar.gz`: one archive per pack (replica, instagram,
  impeccable, unlazy, console). Archives keep the upload under its 200-file
  limit. Each holds the pack's skill folders (instructions in
  `INSTRUCTIONS.md`, the skill's original `SKILL.md` renamed because an
  upload may contain only one `SKILL.md`), their scripts and data, any
  `*-agents/` sub-agent folder, and the pack's license.
- Account skills (docx, pdf, computer-use, ...) are listed in `registry.md`
  by name only. They are already in every session: invoke them with the
  Skill tool as `anthropic-skills:<name>`, never from `library/`.

## Unpacking a pack

Before reading or running any skill from the library, extract its pack into
the session's scratch directory (once per session; reuse it if it is already
there):

```bash
mkdir -p <scratch>/my-skills-lib
tar -xzf <this skill's base directory>/library/<pack>.tar.gz -C <scratch>/my-skills-lib
```

The skill is then at `<scratch>/my-skills-lib/<pack>/<skill-name>/`. Find
which pack a skill belongs to in `registry.md` (`ig-*` is `instagram`,
`replica-*` is `replica`, `console-*` is `console`). To list what an archive
holds without extracting: `tar -tzf library/<pack>.tar.gz`.

## "List my skills / tools"

Read `registry.md` and answer from it, grouped by pack (Replica, Instagram,
Impeccable, Unlazy, Console, account skills, account plugins, tools): the
command name and one line on what it does. The registry rows name every
skill; for a fuller one-line description, extract the pack and read the
frontmatter of `<skill>/INSTRUCTIONS.md`. Also list removed tools and
refused items, so nothing is forgotten. Do not list skills that are not in
the registry as the owner's.

## "Bring me / use skill X"

1. Find it: match the name, or the meaning (e.g. "مهارة الريلز" is `ig-reel`,
   "استنساخ موقع" starts with `replica-recon`). If several match, list them
   and ask which.
2. Extract its pack (see above), read `<skill>/INSTRUCTIONS.md` and follow it
   as if it were loaded. Its scripts are in the same folder; run them from
   there with absolute paths (e.g. `python3 -I <dir>/<script>.py ...`).
3. If the user wants it installed in the current project as well, copy the
   skill folder to `<project>/.claude/skills/<name>/`, rename
   `INSTRUCTIONS.md` back to `SKILL.md`, put the pack's license next to it,
   copy any `*-agents/*.md` to `<project>/.claude/agents/`, and say it will
   load as `/<name>` in the next session. Copying into the project changes
   the repository, so mention it and commit only if the user asks or the
   project's instructions say so.

## "Bring me tool X"

Tools (CLI programs) are not stored here, only recorded. Read the tool's row
in `registry.md` for its install command and notes, reinstall it in the
current environment, and tell the user. If the registry says it was removed
at the owner's request, ask before reinstalling it.

## Refused items

If the user asks for something listed under "Refused", say it was refused
before and why (from the registry), and do not install it.

## Keeping the library current

This folder is read-only inside a session; it updates only when the owner
uploads a new version. When something is installed, removed or refused in a
session:

1. Do the work, and update the project's own registry if it has one
   (`.claude/INSTALLED.md`).
2. Build an updated copy of this skill: copy this folder to a scratch
   directory, add the new pack as `library/<pack>.tar.gz` (one top-level
   `<pack>/` folder inside, each skill's `SKILL.md` renamed to
   `INSTRUCTIONS.md`, license included) or remove one, edit `registry.md`,
   and zip the folder with `my-skills/` at its root. Check before handing it
   over: exactly one `SKILL.md`, and well under 200 files in total.
3. Give the zip to the user with one line: upload it in claude.ai under
   Customize, Skills, replacing the old `my-skills`.
