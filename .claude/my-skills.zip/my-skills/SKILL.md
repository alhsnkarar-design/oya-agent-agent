---
name: my-skills
description: The owner's personal library of every skill and tool they have installed, removed or refused, with full copies of the installed skills. Use whenever the user asks to list their skills or tools, asks what is installed, or asks to bring, load, use, install or run a skill or tool by name, in Arabic or English, e.g. "لستة المهارات", "قائمة الأدوات", "هات مهارة", "جيبلي المهارة", "ثبتلي", "شغل مهارة", "what skills do I have", "bring me ig-reel". Also use after installing, removing or refusing any skill or tool, to tell the user how to keep this library current.
license: Bundled skills keep their own MIT licenses (library/*-LICENSE)
---

# My skills library

The owner wants to ask for their skills and tools in any session, in any
repository, without doing anything themselves. This skill is that memory.
Reply in Arabic unless the user writes in another language.

Files in this folder:

- `registry.md`: every skill pack and tool, its source URL, what it contains,
  when it was installed, plus what was removed and what was refused and why.
- `library/<skill-name>/`: a full copy of each installed skill. Its
  instructions are in `INSTRUCTIONS.md` (the skill's original `SKILL.md`,
  renamed because an uploaded skill may contain only one `SKILL.md`), next to
  its scripts and data files.
- `library/*-LICENSE`: the license of each pack. Keep them with the copies.
- Account skills (docx, pdf, computer-use, ...) are listed in `registry.md`
  by name only. They are already in every session: invoke them with the
  Skill tool as `anthropic-skills:<name>`, never from `library/`.

## "List my skills / tools"

Read `registry.md` and answer from it, grouped by pack (Replica, Instagram,
account skills, account plugins): the command name and
one line on what it does (take it from the frontmatter of each `library/<name>/INSTRUCTIONS.md`
description). Also list removed tools and refused items, so nothing is
forgotten. Do not list skills that are not in the registry as the owner's.

## "Bring me / use skill X"

1. Find it: match the name, or the meaning (e.g. "مهارة الريلز" is `ig-reel`,
   "استنساخ موقع" starts with `replica-recon`). If several match, list them
   and ask which.
2. Use it directly: read `library/<name>/INSTRUCTIONS.md` and follow it as if it
   were loaded. Its scripts are in the same folder; run them from there with
   `python3 library/<name>/<script>.py ...` (use this skill's base directory
   to build the absolute path).
3. If the user wants it installed in the current project as well, copy the
   folder to `<project>/.claude/skills/<name>/`, rename `INSTRUCTIONS.md`
   back to `SKILL.md`, put the pack's license file next to it, and say it will load as `/<name>` in the next session.
   Copying into the project changes the repository, so mention it and commit
   only if the user asks or the project's instructions say so.

## "Bring me tool X"

Tools (CLI programs) are not stored here, only recorded. Read the tool's row
in `registry.md` for its install command and notes, reinstall it in the
current environment, and tell the user. If the registry says it was removed
at the owner's request, ask before reinstalling it.

## Refused items

If the user asks for something listed under "Refused", say it was refused
before and why (from the registry), and do not install it.

## Keeping the library current

This folder is read-only inside a session; it updates only when the owner
uploads a new version. When something is installed, removed or refused in a
session:

1. Do the work, and update the project's own registry if it has one
   (`.claude/INSTALLED.md`).
2. Build an updated copy of this skill: copy this folder to a scratch
   directory, add or remove `library/<name>/` and its license, edit
   `registry.md`, rename each added skill's `SKILL.md` to `INSTRUCTIONS.md`
   (the zip may hold only one `SKILL.md`), and zip the folder (the zip must contain the `my-skills/`
   folder at its root).
3. Give the zip to the user with one line: upload it in claude.ai under
   Customize, Skills, replacing the old `my-skills`.
